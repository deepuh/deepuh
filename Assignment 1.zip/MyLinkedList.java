
public class MyLinkedList<Type extends Comparable<Type>> {
    private class Node {
        private Type item;
        private Node next;

        /**
         * toString - Returns the toString of item.
         */
        public String toString() {
            return item.toString();
        }

        public Node(Type item) {

            this.item = item;
            this.next = null;
        }

    }

    private Node first, current, previous;
    private int size;
    private long comparisons;

    public MyLinkedList() {
        first = current = previous = null;
        size = 0;
    }

    public MyLinkedList(Type type) {
        current = new Node(type);
        previous = null;
        first = current;
        size = 1;
    }

    public long getComparisons() {
        return comparisons;
    }

    /**
     * addBefore-Adds the item before the current Node.If the current Node is
     * null the new element is added in the last position. This is a common means of adding
     * elements into a linked list. This method should run in O(1) time.
     */

    // First -- Previous - AddItem(Temp) - Current
    public void addBefore(Type item) {
        Node temp = new Node(item);
        if (current == null) {

            if (previous != null) {
                previous.next = temp;
            } else {
                first = temp;
            }
            previous = temp;
        } else {
            if (previous != null) {
                previous.next = temp;
            }
            temp.next = current;
            previous = temp;
        }
        size++;
    }

    /**
     * addAfter-Adds the item after the current Node.If the current Node is
     * null this method does nothing. This is a common means of adding elements into a
     * linked list. This method should run in O(1) time.
     */
    public void addAfter(Type item) {
        if (current != null) {
            Node temp = new Node(item);
            temp.next = current.next;
            current.next = temp;
            size++;
        }
    }

    /**
     * remove-Removes the current Node and returns the element.Any elements after
     * the removed element shuffle down to fill the empty position. If the current Node is
     * null this method does nothing. This is a common means of deleting elements from a
     * linked list. This method should run in O(1) time.
     */
    public Type remove() {
        Type itemRemove = null;
        if (current != null) {
            itemRemove = current.item;
            if (current == first) {
                if (first.next == null) {
                    previous = null;
                }
                first = first.next;
            }
            current = current.next;
            if (previous != null) {
                previous.next = current;
            }
            size--;
        }

        return itemRemove;
    }

    /**
     * current-Returns the item stored in the current Node.This method returns
     * null if the current Node is null. This method should run in O(1) time.
     */
    public Type current() {
        if (current != null) {
            return current.item;
        } else
            return null;
    }

    /**
     * first-Sets the current Node to be the first Node and returns the item
     * stored in it. This method returns null if the first Node is null. This method
     * should run in O(1) time.
     */
    public Type first() {
        previous = null;
        current = first;
        if (first != null) {
            return first.item;
        } else
            return null;
    }

    /**
     * next-Sets the current Node to be the next node in the list and returns the item
     * stored in it. This method returns null if the current Node is null. This method
     * should run in O(1) time.
     */
    public Type next() {
        if (current != null) {
            previous = current;
            current = current.next;
        }

        if (current != null) {
            return current.item; // return the item of next current
        } else {
            return null;
        }
    }

    /**
     * contains-Searches the Nodes for the item and returns true if found(and false
     * otherwise). This is the standard search in a linked list. This method should run in O(n) time.
     */
    public boolean contains(Type item) {
        Node temp = first;
        comparisons++;
        while (temp != null) {
            comparisons++;
            if (temp.item.compareTo(item) == 0) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    /**
     * size-Returns the field size. This method should run in O(1)time.
     */
    public int size() {
        return size;
    }

    /**
     * isEmpty-Returns true if the size is 0 and false otherwise.This method should run in O(1) time.
     */
    public boolean isEmpty() {
        if (size() == 0)
            return true;
        else
            return false;
    }

    /**
     * toString-Returns a string that has the contents of theNodes separated by
     * commas and spaces and enclosed in square brackets. This method should run in O(n) time.
     * ○ Example: [1, 2, 3, 4]
     */
    public String toString() {
        String st = "[";
        Node temp = first;
        while (temp != null) {
            if (temp.next == null) {
                st += temp.item;
            } else {
                st += temp.item + ", ";
            }
            temp = temp.next;
        }

        st += "]";
        return st;
    }

    /**
     * addToFront-Adds the item to the front of the list.This helper function is optional.
     * This method should run in O(1) time.
     */
    public void addToFront(Type item) {
        Node temp = new Node(item);
        if (first != null) {
            temp.next = first;
            first = temp;
        } else {
            first = temp;
        }
        size++;
    }

    /**
     * moveToFront-Moves the current Node to the front of the list.
     * This helper function is optional. This method should run in O(1) time.
     */
    public void moveToFront() {
        Type item = remove();
        addToFront(item);

    }

    public void addToBack(Type item) {
        Node temp = new Node(item);
        Node back = first;
        if (back == null) {
            first = temp;
        } else {
            while (back.next != null) {
                back = back.next;
            }
            back.next = temp;
        }
        size++;
    }


    public void swapWithPrevious() {
        if (current != first && current != null) {
            Type temp = current.item;
            current.item = previous.item;
            previous.item = temp;
        }
    }

    public void sort() {
        int i, j;
        //use bubble sort
        for (i = 0; i < size; i++) {
            Node temp = first;
            Node next = first.next;
            for (j = 0; j < size - 1; j++) {
                if (temp.item.compareTo(next.item) > 0) {
                    Type br = temp.item;
                    temp.item = next.item;
                    next.item = br;
                }
                temp = next;
                next = next.next;
            }
        }
    }


}




