//package com;

import java.util.Arrays;

public class MyArrayList <Type extends Comparable<Type>>{
    private Type[] list;
    private int capacity;
    private int size;
    private long comparisons;

    public MyArrayList(){
        capacity = 16;
        size = 0;
        list = (Type[]) new Comparable[capacity];
    }
    public MyArrayList( int capacity) {
        size = 0;
        //list = (Type[]) new Object[capacity];
        list = (Type[]) new Comparable[capacity];
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }

    public long getComparisons(){
        return comparisons;
    }


    /**
     * add(Type item): insert the item into last index
     */
    public void add(Type item){
        list[size] = item;
        size++;
        if(size >= capacity){
            resize();
        }
    }

    /**
     insert() - Inserts the item at position index. Any elements after the inserted
     element shuffle down one position. If the index is greater than the size then this
     method does nothing. This is the primary means of adding elements into a dynamically
     sized array. This method should run in O(i) time where i is the number of elements
     shuffled.
     */
    public void insert(Type item, int index){
        if  (index >= 0 && index <= size){
            for(int i = size-1 ; i >= index; i--){
                list[i+1] = list[i];
            }
            list[index] = item;
            size++;
            if(size >= capacity){
                resize();
            }
        }

    }

    /**
     * remove - Removes the element at position index and returns the element. Any
     * elements after the removed element shuffle down to fill the empty position. If the index
     * is out of bounds this method does nothing and returns null. This is the primary means
     * of deleting elements from a dynamically sized array. This method should run in O(i) time
     * where i is the number of elements shuffled.
     */
    public Type remove(int index){
        Type itemRemove;
        if(index >= 0 && index < size){
            itemRemove = list[index];
            for(int i = index ; i < size - 1; i++){
                list[i] = list[i+1];
            }
            size--;
            return  itemRemove;
        }
        else {
            return null;
        }
    }

    /**
     * contains - Searches the list for the item and returns true if found (and false
     * otherwise). This function should be upgraded to use Comparable.compareTo(Type)to compare elements.
     * This is one of two standard searches in a list. This method should run in O(n)
     * time.
     */
    public boolean contains(Type item){
        comparisons++;
        for(int i = 0; i < size; i++){
            comparisons++;
            if(list[i].compareTo(item) == 0){
                return true;
            }
        }
        return false;
    }

    /**
     * indexOf - Searches the list for the item and returns the index if found (and -1
     * otherwise). This function should be upgraded to use Comparable.compareTo(Type)to compare elements.
     * This is one of two standard searches in a list. This method should run in O(n)
     * time.
     */
    public int indexOf(Type item){
        for(int i = 0; i < size; i++){
            if(list[i].compareTo(item) == 0){
                return i;
            }
        }
        return -1;
    }

    /**
     * get - Returns the element stored at index and null if the index is out of bounds.
     * This method should run in O(1) time.
     */
    public Type get(int index){
        if(index >= 0 && index < size){
            return list[index];
        }
        else {
            return null;
        }
    }

    /**
     * set - Updates the element stored at index and does nothing if the index is out of
     * bounds. This method should run in O(1) time.
     */
    public void set(int index, Type item){
        if(index >= 0 && index < size ){
            list[index] = item;
        }
    }

    /**
     * size - Returns the field size. This method should run in O(1) time.
     */
    public int size(){
        return size;
    }

    /**
     * isEmpty - Returns true if the size is 0 and false otherwise. This method should run
     * in O(1) time.
     */
    public boolean isEmpty(){
        if(size() == 0){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * toString - Returns a string that has the contents of the list separated by commas
     * and spaces and enclosed in square brackets. This method should run in O(n) time.
     */
    public String toString(){
        String st = "[";
        for(int i = 0 ; i < size; i++){
            if(i == size - 1){
                st += list[i];
            }
            else {
                st += list[i] + ", ";
            }
        }
        st += "]";
        return st;
    }

    /**
     * resize - Called by insert when the list is full. Doubles the capacity of the
     * list and copies the elements into a new array. This method should run in O(n) time.
     */
    public void resize(){
        capacity *= 2;
        list = Arrays.copyOf(list,capacity);
    }

    /**
     * sort-Sorts the list in ascending order.
     * @return
     */
    //---a--b--c---
    public void sort(){

        //insert sort
        /*int i, j;
        Type temp;
        for (i = 1; i < size; i++)
        {
            temp = list[i];
            for (j = i - 1;j >= 0 && list[j].compareTo(temp) > 0;j--)
            {
                list[j + 1] = list[j];
            }
            list[j + 1] = temp;
        }*/
        quickSort(0,size-1);
        //quickSort1(0, size-1);
    }

    private void quickSort (int left, int right) {
        Type mid, temp;
        int iLeft = left, iRight = right;
        mid = list [(left + right) / 2];

        // Sorting data array in ascending order
        while (iLeft <= iRight)
        {
            while ((iLeft < right) && (list [iLeft].compareTo(mid) < 0)) iLeft++;
            while ((left < iRight) && (list [iRight].compareTo(mid) > 0)) iRight--;

            if (iLeft <= iRight)
            {
                temp = list [iLeft];
                list [iLeft] = list [iRight];
                list [iRight] = temp;

                iLeft++;
                iRight--;
            }
        }

        // Recursion
        if (left < iRight)
            quickSort (left, iRight);
        if (iLeft < right)
            quickSort (iLeft, right);
    }

    public void quickSort1(int start, int finish){
        if(start < finish){
            int temp = start;
            for(int i = start; i < finish + 1; ){
                if(list[i].compareTo(list[start]) < 0){ //--6--9---
                    swap(++temp,i);
                }
            }
            swap(start,temp);
            quickSort(start, temp);
            quickSort(temp+1, finish);
        }
    }
    public void swap(int left, int right ){
        Type temp = list[left];
        list[left] = list[right];
        list[right] = temp;
    }


}

